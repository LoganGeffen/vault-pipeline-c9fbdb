import csv
import json
from pathlib import Path

text = json.loads(Path("inputs.json").read_text())["text"]
if not isinstance(text, str) or not text.strip():
    raise SystemExit("Expected nonempty text")
Path("output").mkdir(exist_ok=True)
with Path("output/training_echo.csv").open("w", newline="", encoding="utf-8") as output:
    writer = csv.writer(output)
    writer.writerow(["input", "characters"])
    writer.writerow([text, len(text)])
