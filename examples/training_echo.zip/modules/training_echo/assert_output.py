import csv
import json
from pathlib import Path

text = 'SSC training, "hello"'
with Path("output/training_echo.csv").open(newline="", encoding="utf-8") as output:
    actual = list(csv.reader(output))
expected = [["input", "characters"], [text, str(len(text))]]
if actual != expected:
    raise SystemExit(f"Unexpected CSV contents: {actual!r}")
Path("assertion-summary.json").write_text(json.dumps({"status": "pass", "rows": 1, "characters": len(text)}) + "\n")
print("PASS exact CSV content, escaping and character count")
